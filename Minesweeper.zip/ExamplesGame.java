import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import javalib.worldimages.*;
import tester.*;

class ExamplesGame {

  // example Cells, example Rows, and example Games
  Cell cell1;
  Cell cell2;
  Cell cell3;
  Cell cell4;
  Cell cell5;
  Cell cell6;
  Cell cell7;
  Cell cell8;
  Cell cell9;
  Cell cell10;
  Cell cell11;
  Cell cell12;
  Cell cell13;
  Cell cell14;
  Cell cell15;
  Cell cell16;
  Row row1;
  Row row2;
  Row row3;
  Row row4;
  Game game1;
  ArrayList<Posn> game1Mines;

  Cell cell17;
  Cell cell18;
  Cell cell19;
  Cell cell20;
  Cell cell21;
  Cell cell22;
  Cell cell23;
  Cell cell24;
  Cell cell25;
  Row row5;
  Row row6;
  Row row7;
  Game game2;
  ArrayList<Posn> game2Mines;

  Cell cell26;
  Cell cell27;
  Cell cell28;
  Cell cell29;
  Cell cell30;

  Integer cellDimension;
  WorldImage flag;
  WorldImage bomb;
  WorldImage frame;
  WorldImage unrevealed;
  WorldImage revealed;

  // initialize all data
  void initData() {

    // example Cells, example Rows, and example Games
    this.cell1 = new Cell();
    this.cell2 = new Cell();
    this.cell3 = new Cell();
    this.cell4 = new Cell();
    this.cell5 = new Cell();
    this.cell6 = new Cell();
    this.cell7 = new Cell();
    this.cell8 = new Cell();
    this.cell9 = new Cell();
    this.cell10 = new Cell();
    this.cell11 = new Cell();
    this.cell12 = new Cell();
    this.cell13 = new Cell();
    this.cell14 = new Cell();
    this.cell15 = new Cell();
    this.cell16 = new Cell();
    this.row1 = new Row(new ArrayList<Cell>(Arrays.asList(cell1, cell2, cell3, cell4)));
    this.row2 = new Row(new ArrayList<Cell>(Arrays.asList(cell5, cell6, cell7, cell8)));
    this.row3 = new Row(new ArrayList<Cell>(Arrays.asList(cell9, cell10, cell11, cell12)));
    this.row4 = new Row(new ArrayList<Cell>(Arrays.asList(cell13, cell14, cell15, cell16)));
    this.game1 = new Game(new ArrayList<Row>(Arrays.asList(row1, row2, row3, row4)), new Random(0));
    this.game1Mines = new ArrayList<Posn>(
        Arrays.asList(new Posn(2, 0), new Posn(2, 3), new Posn(1, 1)));

    this.cell17 = new Cell();
    this.cell18 = new Cell();
    this.cell19 = new Cell();
    this.cell20 = new Cell();
    this.cell21 = new Cell();
    this.cell22 = new Cell();
    this.cell23 = new Cell();
    this.cell24 = new Cell();
    this.cell25 = new Cell();
    this.row5 = new Row(new ArrayList<Cell>(Arrays.asList(cell17, cell18, cell19)));
    this.row6 = new Row(new ArrayList<Cell>(Arrays.asList(cell20, cell21, cell22)));
    this.row7 = new Row(new ArrayList<Cell>(Arrays.asList(cell23, cell24, cell25)));
    this.game2 = new Game(new ArrayList<Row>(Arrays.asList(row5, row6, row7)), new Random(5));
    this.game2Mines = new ArrayList<Posn>(Arrays.asList(new Posn(0, 2), new Posn(1, 2)));

    this.cell26 = new Cell();
    this.cell27 = new Cell(false, false, true);
    this.cell28 = new Cell(true, true, true);
    this.cell29 = new Cell(true, false, true);
    this.cell30 = new Cell(true, false, false,
        new ArrayList<Cell>(Arrays.asList(cell26, cell27, cell28, cell29)));

    this.cellDimension = 40;
    this.flag = new TriangleImage(new Posn(20, 10), new Posn(10, 30), new Posn(30, 30),
        OutlineMode.SOLID, Color.YELLOW);
    this.bomb = new CircleImage(10, OutlineMode.SOLID, Color.RED);
    this.frame = new RectangleImage(cellDimension, cellDimension, OutlineMode.OUTLINE, Color.BLACK);
    this.unrevealed = new OverlayImage(frame,
        new RectangleImage(cellDimension, cellDimension, OutlineMode.SOLID, Color.BLUE));
    this.revealed = new OverlayImage(frame,
        new RectangleImage(cellDimension, cellDimension, OutlineMode.SOLID, Color.LIGHT_GRAY));
  }

  // test the method updateNeighbors() and all helper methods
  void testUpdateNeighbors(Tester t) {
    this.initData();
    Cell row1Cell1 = game1.rows.get(0).cells.get(0);
    Cell row2Cell1 = game1.rows.get(1).cells.get(0);
    Cell row3Cell2 = game1.rows.get(2).cells.get(1);
    Cell row4Cell4 = game1.rows.get(3).cells.get(3);

    t.checkExpect(row1Cell1.neighbors.size(), 3);
    t.checkExpect(row2Cell1.neighbors.size(), 5);
    t.checkExpect(row3Cell2.neighbors.size(), 8);
    t.checkExpect(row4Cell4.neighbors.size(), 3);
  }

  // test the method neighboringMines()
  boolean testNeighboringMines(Tester t) {
    return t.checkExpect(this.cell1.neighboringMines(), 0)
        && t.checkExpect(this.cell16.neighboringMines(), 1)
        && t.checkExpect(this.cell27.neighboringMines(), 0);
  }

  // test the method generateMines()
  boolean testGenerateMines(Tester t) {
    this.initData();

    return t.checkExpect(game1.generateMines(), game1Mines)
        && t.checkExpect(game2.generateMines(), game2Mines);
  }

  // test the method addMines(ArrayList<Posn> mineList)
  void testAddMines(Tester t) {
    this.initData();
    Cell game1Row3Cell1 = game1.rows.get(2).cells.get(0);
    Cell game1Row4Cell2 = game1.rows.get(3).cells.get(1);
    Cell game2Row2Cell3 = game2.rows.get(1).cells.get(2);
    Cell game2Row2Cell2 = game2.rows.get(1).cells.get(1);

    t.checkExpect(game1Row3Cell1.hasMine, true);
    t.checkExpect(game1Row4Cell2.hasMine, false);
    t.checkExpect(game2Row2Cell3.hasMine, true);
    t.checkExpect(game2Row2Cell2.hasMine, false);
  }

  // test the method drawCell()
  boolean testDrawCell(Tester t) {
    this.initData();

    return t.checkExpect(cell26.drawCell(), unrevealed)
        && t.checkExpect(cell27.drawCell(), new OverlayImage(flag, unrevealed))
        && t.checkExpect(cell28.drawCell(), new OverlayImage(bomb, revealed))
        && t.checkExpect(cell29.drawCell(), revealed) && t.checkExpect(cell30.drawCell(),
            new OverlayImage(new TextImage("1", 20, Color.BLUE), revealed));
  }

  // test the method drawRevealed()
  boolean testDrawRevealed(Tester t) {
    this.initData();

    return t.checkExpect(cell27.drawCell(), new OverlayImage(flag, unrevealed))
        && t.checkExpect(cell28.drawCell(), new OverlayImage(bomb, revealed))
        && t.checkExpect(cell29.drawCell(), revealed) && t.checkExpect(cell30.drawCell(),
            new OverlayImage(new TextImage("1", 20, Color.BLUE), revealed));
  }

  // test the method drawRevealedHelp()
  boolean testDrawRevealedHelp(Tester t) {
    this.initData();

    return t.checkExpect(cell27.drawCell(), new OverlayImage(flag, unrevealed))
        && t.checkExpect(cell29.drawCell(), revealed) && t.checkExpect(cell30.drawCell(),
            new OverlayImage(new TextImage("1", 20, Color.BLUE), revealed));
  }

  // test the method revealCell()
  void testRevealCell(Tester t) {
    this.initData();
    t.checkExpect(this.cell1.isRevealed, false);
    this.cell1.revealCell();
    t.checkExpect(this.cell1.isRevealed, true);
  }

  // test the method floodFill()
  void testFloodFill(Tester t) {
    this.initData();
    
    t.checkExpect(this.cell27.isRevealed, false);
    this.cell27.floodFill();
    t.checkExpect(this.cell27.isRevealed, false);
  }

  // test the method floodFillHelp()
  void testFloodFillHelp(Tester t) {
    this.initData();
    t.checkExpect(this.cell27.isRevealed, false);
    this.cell27.floodFill();
    t.checkExpect(this.cell27.isRevealed, false);
  }

  // test the method isFillable()
  boolean testIsFillable(Tester t) {
    this.initData();

    return t.checkExpect(this.cell1.isFillable(), true)
        && t.checkExpect(this.cell27.isFillable(), true);
  }

  // test the method drawRow()
  boolean testDrawRow(Tester t) {
    this.initData();

    return t.checkExpect(row1.drawRow().getWidth(), 160.0)
        && t.checkExpect(row1.drawRow().getHeight(), 40.0)
        && t.checkExpect(row5.drawRow().getWidth(), 120.0)
        && t.checkExpect(row5.drawRow().getHeight(), 40.0);
  }

  // test the method drawGame()
  boolean testDrawGame(Tester t) {
    this.initData();

    return t.checkExpect(game1.drawGame().getWidth(), 1240.0)
        && t.checkExpect(game1.drawGame().getHeight(), 760.0)
        && t.checkExpect(game2.drawGame().getWidth(), 1240.0)
        && t.checkExpect(game2.drawGame().getHeight(), 760.0);
  }

  // test the method drawTimer()
  boolean testDrawTimer(Tester t) {
    this.initData();
    WorldImage background = new RectangleImage(110, 50, OutlineMode.SOLID, Color.BLACK);
    WorldImage spacer = new RectangleImage(110, 5, OutlineMode.SOLID, Color.BLACK);
    WorldImage timer = new TextImage("0", 15, Color.RED);
    WorldImage heading = new TextImage("Time Elapsed:", 15, Color.WHITE);

    return t.checkExpect(this.game1.drawTimer(),
        new OverlayImage(new AboveImage(heading, new AboveImage(spacer, timer)), background));
  }

  // test the method drawMineCount()
  boolean testDrawMineCount(Tester t) {
    this.initData();
    WorldImage background = new RectangleImage(110, 50, OutlineMode.SOLID, Color.BLACK);
    WorldImage spacer = new RectangleImage(110, 5, OutlineMode.SOLID, Color.BLACK);
    WorldImage counter = new TextImage("3", 15, Color.RED);
    WorldImage heading = new TextImage("Mines Left:", 15, Color.WHITE);

    return t.checkExpect(this.game1.drawMineCount(),
        new OverlayImage(new AboveImage(heading, new AboveImage(spacer, counter)), background));
  }

  // test the method drawStartOver()
  boolean testDrawStartOver(Tester t) {
    this.initData();
    WorldImage background = new RectangleImage(160, 40, OutlineMode.SOLID, Color.WHITE);
    WorldImage frame = new RectangleImage(160, 40, OutlineMode.OUTLINE, Color.BLACK);
    WorldImage text = new TextImage("Start Over", 20, Color.BLACK);
    return t.checkExpect(this.game1.drawStartOver(),
        new OverlayImage(text, new OverlayImage(frame, background)));
  }

  // test the method drawHeader()
  boolean testDrawHeader(Tester t) {
    this.initData();
    WorldImage headerBackground = new RectangleImage(1200, 100, OutlineMode.SOLID,
        Color.LIGHT_GRAY);
    WorldImage title = new TextImage("MINESWEEPER", 30, Color.BLUE);

    WorldImage titleOnBG = new OverlayOffsetImage(title, 0, 25, headerBackground);
    WorldImage startOver = new OverlayOffsetImage(this.game1.drawStartOver(), 0, -20, titleOnBG);
    WorldImage timer = new OverlayOffsetImage(this.game1.drawTimer(), -500, 0, startOver);

    return t.checkExpect(this.game1.drawHeader(),
        new OverlayOffsetImage(this.game1.drawMineCount(), 500, 0, timer));
  }

  // test the method onMouseClicked(Posn p, String button)
  void testOnMouseClicked(Tester t) {
    this.initData();

    this.game1.onMouseClicked(new Posn(200, 200), "LeftButton");
    t.checkExpect(this.cell2.isRevealed, false);
  }

  // test the method leftClicked()
  void testLeftClicked(Tester t) {
    this.initData();
    t.checkExpect(this.cell1.isRevealed, false);
    this.game1.leftClicked(new Posn(200, 200), this.cell1);
    t.checkExpect(this.cell1.isRevealed, true);
  }

  // test the method rightClicked()
  void testRightClicked(Tester t) {
    this.initData();
    t.checkExpect(this.cell2.isRevealed, false);
    this.game1.rightClicked(new Posn(1200, 1200), this.cell2);
    t.checkExpect(this.cell2.isRevealed, false);
  }

  // test the method makeInitialRows() and makeInititalRow()
  boolean testMakeInitialRows(Tester t) {
    this.initData();

    return t.checkExpect(new Utils().makeInitialRows().size(), 16)
        && t.checkExpect(new Utils().makeInititalRow().cells.size(), 30);
  }

  // test the method determineRow(Posn p)
  boolean testDetermineRow(Tester t) {
    this.initData();

    return t.checkExpect(game1.determineRow(new Posn(80, 5)), 3)
        && t.checkExpect(game1.determineRow(new Posn(30, 100)), 3)
        && t.checkExpect(game1.determineRow(new Posn(100, 70)), 3)
        && t.checkExpect(game1.determineRow(new Posn(100, 140)), 2);
  }

  // test the method determineCell(Posn p) in class game
  boolean testDetermineCellGame(Tester t) {
    this.initData();

    return t.checkExpect(game1.determineCell(new Posn(80, 5)), 2)
        && t.checkExpect(game1.determineCell(new Posn(30, 100)), 3)
        && t.checkExpect(game1.determineCell(new Posn(130, 70)), 1)
        && t.checkExpect(game1.determineCell(new Posn(45, 120)), 3);
  }

  // test the method determineCell(int xPos) in class Row
  boolean testDetermineCellRow(Tester t) {
    this.initData();

    return t.checkExpect(row1.determineCell(80), 2) && t.checkExpect(row1.determineCell(30), 3)
        && t.checkExpect(row3.determineCell(130), 1) && t.checkExpect(row4.determineCell(45), 3);
  }

  // test the method minesLeft()
  boolean testMinesLeft(Tester t) {
    return t.checkExpect(this.game1.minesLeft(), 3) && t.checkExpect(this.game2.minesLeft(), 2);
  }

  // test the method worldEnds()
  boolean testWorldEnds(Tester t) {
    this.initData();
    return t.checkExpect(this.game1.worldEnds(),
        new WorldEnd(this.game1.hasGameEnded(), this.game1.drawEnding()));
  }

  // test the method hasGameEnded() - NOT SURE HOW TO TEST??
  boolean testHasGameEnded(Tester t) {
    this.initData();
    return t.checkExpect(this.game1.hasGameEnded(), false)
        && t.checkExpect(this.game2.hasGameEnded(), false);
  }

  // test the method hasClickedMine() - NOT SURE HOW TO TEST??
  boolean testHasClickedMine(Tester t) {
    this.initData();
    return t.checkExpect(this.game1.hasClickedMine(), false)
        && t.checkExpect(this.game2.hasClickedMine(), false);
  }

  // test the method onlyMinesLeft() - NOT SURE HOW TO TEST??
  boolean testOnlyMinesLeft(Tester t) {
    this.initData();
    return t.checkExpect(this.game1.onlyMinesLeft(), false)
        && t.checkExpect(this.game2.onlyMinesLeft(), false);
  }

  // test the method endingMesage()
  boolean testEndingMesage(Tester t) {
    this.initData();
    return t.checkExpect(this.game1.endingMesage(), new TextImage("You Won!", 40, Color.BLUE))
        && t.checkExpect(this.game2.endingMesage(), new TextImage("You Won!", 40, Color.BLUE));
  }

  // test the method onTick()
  void testOnTick(Tester t) {
    this.initData();
    this.game1.onTick();
    t.checkExpect(this.game1.timeCount, 1);
    this.game2.onTick();
    t.checkExpect(this.game2.timeCount, 1);
  }

  // test the method currentTime()
  boolean testCurrentTime(Tester t) {
    this.initData();
    return t.checkExpect(this.game1.currentTime(), 0) 
        && t.checkExpect(this.game2.currentTime(), 0);
  }

  // test the method updateNeighborsEdge(Row other)
  void testUpdateNeigborsEdge(Tester t) {
    this.initData();
    
    row1.updateNeighborsEdge(row2);
    t.checkExpect(row1.cells.get(0).neighbors.size(), 6);
    t.checkExpect(row1.cells.get(1).neighbors.size(), 10);
    
    row4.updateNeighborsEdge(row3);
    t.checkExpect(row4.cells.get(0).neighbors.size(), 6);
    t.checkExpect(row4.cells.get(3).neighbors.size(), 6);
    t.checkExpect(row4.cells.get(2).neighbors.size(), 10);
    
  }
  
  // test the method updateEdgeHelp(Row other, int i)
  void testUpdateEdgeHelp(Tester t) {
    this.initData();
    
    row1.updateEdgeHelp(row2, 2);
    t.checkExpect(row1.cells.get(1).neighbors.size(), 5);
    t.checkExpect(row1.cells.get(3).neighbors.size(), 3);
    
    row4.updateEdgeHelp(row3, 3);
    t.checkExpect(row4.cells.get(0).neighbors.size(), 3);
    t.checkExpect(row4.cells.get(3).neighbors.size(), 6);
    t.checkExpect(row4.cells.get(2).neighbors.size(), 5);
    
  }
  
  // test the method updateNeighborsMiddle(Row other)
  void testUpdateNeighborsMiddle(Tester t) {
    this.initData();
    
    row2.updateNeighborsMiddle(row1, row3);
    t.checkExpect(row2.cells.get(0).neighbors.size(), 10);
    t.checkExpect(row2.cells.get(3).neighbors.size(), 10);
    
    row3.updateNeighborsMiddle(row2, row4);
    t.checkExpect(row3.cells.get(1).neighbors.size(), 16);
    t.checkExpect(row3.cells.get(2).neighbors.size(), 16);
  }
  
  // test the method updateMiddleHelp(Row other, int i)
  void testUpdateMiddleHelp(Tester t) {
    this.initData();
    
    row2.updateMiddleHelp(row1, row3, 2);
    t.checkExpect(row2.cells.get(0).neighbors.size(), 5);
    t.checkExpect(row2.cells.get(2).neighbors.size(), 16);
    
    row3.updateMiddleHelp(row2, row4, 3);
    t.checkExpect(row3.cells.get(1).neighbors.size(), 8);
    t.checkExpect(row3.cells.get(3).neighbors.size(), 10);
    
  }
  
  // test the method unrevealedLeft()
  boolean testUnrevealedLeft(Tester t) {
    this.initData();
    
    return t.checkExpect(this.row1.unrevealedLeft(), 4)
        && t.checkExpect(this.row2.unrevealedLeft(), 3)
        && t.checkExpect(this.row3.unrevealedLeft(), 3);
  }

  // test the method countFlags()
  boolean testCountFlags(Tester t) {
    this.initData();
    return t.checkExpect(this.row1.countFlags(), 0) 
        && t.checkExpect(this.row2.countFlags(), 0)
        && t.checkExpect(this.row3.countFlags(), 0);
  }

  // test the method flagClicked()
  void testFlagClicked(Tester t) {
    this.initData();

    t.checkExpect(cell1.isFlagged, false);
    cell1.flagClicked();
    t.checkExpect(cell1.isFlagged, true);
    cell1.flagClicked();
    t.checkExpect(cell1.isFlagged, false);
  }

  // run the game
  void testBigBang(Tester t) {
    Game blankGame = new Game();
    int worldWidth = (int)blankGame.drawGame().getWidth();
    int worldHeight = (int)blankGame.drawGame().getHeight();
    double tickRate = 1.0 / 28.0;


    blankGame.bigBang(worldWidth, worldHeight, tickRate);
  }
}