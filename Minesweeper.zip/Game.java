import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;
import javalib.impworld.*;
import javalib.worldimages.*;

// A Minesweeper game containing the amount of columns and rows, the total mines,
// and all cells in the game
class Game extends World {
  ArrayList<Row> rows;
  Random rand;
  int timeCount;

  // a constructor for Game that takes in all information
  Game(ArrayList<Row> rows, Random rand) {
    this.rows = rows;
    this.rand = rand;
    this.addMines(this.generateMines());
    this.updateNeighbors();
    this.timeCount = 0;
  }

  // a constructor for the game that generates a random number
  Game(ArrayList<Row> rows) {
    this(rows, new Random());
  }

  // a constructor for the game that makes an initial 30x16 grid and sets a new
  // Random
  Game() {
    this(new Utils().makeInitialRows(), new Random());
  }

  double mineProportion = 0.2;

  // ------------------------------------------------------------------------------------

  // update all cells whose positions are represented in the given list to contain
  // a mine
  public void addMines(ArrayList<Posn> mineList) {
    for (Posn p : mineList) {
      Row getRow = this.rows.get(p.y);
      Cell getCell = getRow.cells.get(p.x);
      getCell.hasMine = true;
    }
  }

  // generate the coordinates of all mines in the game as Posns in a list
  public ArrayList<Posn> generateMines() {
    ArrayList<Posn> positionList = new ArrayList<Posn>();
    int boardWidth = this.rows.get(0).cells.size();
    int boardHeight = this.rows.size();
    int mineCount = (int) Math.round(boardWidth * boardHeight * mineProportion);

    while (positionList.size() < mineCount) {
      Posn newPosn = new Posn(this.rand.nextInt(boardWidth), this.rand.nextInt(boardHeight));

      if (!positionList.contains(newPosn)) {
        positionList.add(newPosn);
      }
    }
    return positionList;
  }

  // ------------------------------------------------------------------------------------

  // update the neighbors of each cell in this game to contain the surrounding
  // cells
  public void updateNeighbors() {
    for (int i = 0; i < this.rows.size(); i++) {
      if (i == 0) {
        this.rows.get(0).updateNeighborsEdge(this.rows.get(1));
      }
      else {
        this.updateNeighborsHelp(i);
      }
    }
  }

  // update the neighbors of each cell in this game to contain the surrounding
  // cells, ignoring the first row
  public void updateNeighborsHelp(int i) {
    if (i + 1 == this.rows.size()) {
      this.rows.get(i).updateNeighborsEdge(this.rows.get(i - 1));
    }
    else {
      this.rows.get(i).updateNeighborsMiddle(this.rows.get(i - 1), this.rows.get(i + 1));
    }
  }

  // ------------------------------------------------------------------------------------

  // output the current state of the game as a WorldScene
  public WorldScene makeScene() {
    WorldImage gameImage = this.drawGame();
    WorldScene background = new WorldScene((int) (gameImage.getWidth()),
        (int) (gameImage.getHeight()));

    background.placeImageXY(gameImage, (int) (gameImage.getWidth() / 2.0),
        (int) (gameImage.getHeight() / 2.0));
    return background;

  }

  // draw the current game as an image
  public WorldImage drawGame() {
    WorldImage gameImage = new EmptyImage();
    WorldImage background = new RectangleImage(1240, 760, OutlineMode.SOLID, Color.LIGHT_GRAY);

    for (Row r : this.rows) {
      gameImage = new AboveImage(r.drawRow(), gameImage);
    }

    return new OverlayOffsetImage(new AboveImage(this.drawHeader(), gameImage), 0, 10, background);
  }

  // draw the current timer on the board
  public WorldImage drawTimer() {
    WorldImage background = new RectangleImage(110, 50, OutlineMode.SOLID, Color.BLACK);
    WorldImage spacer = new RectangleImage(110, 5, OutlineMode.SOLID, Color.BLACK);
    WorldImage timer = new TextImage(this.currentTime().toString(), 15, Color.RED);
    WorldImage heading = new TextImage("Time Elapsed:", 15, Color.WHITE);

    return new OverlayImage(new AboveImage(heading, new AboveImage(spacer, timer)), background);
  }

  // draw the current amount of Mines that are left to be found
  public WorldImage drawMineCount() {
    WorldImage background = new RectangleImage(110, 50, OutlineMode.SOLID, Color.BLACK);
    WorldImage spacer = new RectangleImage(110, 5, OutlineMode.SOLID, Color.BLACK);
    WorldImage counter = new TextImage(this.minesLeft().toString(), 15, Color.RED);
    WorldImage heading = new TextImage("Mines Left:", 15, Color.WHITE);

    return new OverlayImage(new AboveImage(heading, new AboveImage(spacer, counter)), background);
  }

  // draw the button to start over
  public WorldImage drawStartOver() {
    WorldImage background = new RectangleImage(160, 40, OutlineMode.SOLID, Color.WHITE);
    WorldImage frame = new RectangleImage(160, 40, OutlineMode.OUTLINE, Color.BLACK);
    WorldImage text = new TextImage("Start Over", 20, Color.BLACK);

    return new OverlayImage(text, new OverlayImage(frame, background));
  }

  // draw the header of this game
  public WorldImage drawHeader() {
    WorldImage headerBackground = new RectangleImage(1200, 100, OutlineMode.SOLID,
        Color.LIGHT_GRAY);
    WorldImage title = new TextImage("MINESWEEPER", 30, Color.BLUE);

    WorldImage titleOnBG = new OverlayOffsetImage(title, 0, 25, headerBackground);
    WorldImage startOver = new OverlayOffsetImage(this.drawStartOver(), 0, -20, titleOnBG);
    WorldImage timer = new OverlayOffsetImage(this.drawTimer(), -500, 0, startOver);

    return new OverlayOffsetImage(this.drawMineCount(), 500, 0, timer);

  }

  // ------------------------------------------------------------------------------------

  // handle the clicking of the mouse to reveal a Cell
  public void onMouseClicked(Posn p, String button) {
    Row selectedRow = this.rows.get(this.determineRow(p));
    Cell selectedCell = selectedRow.cells.get(this.determineCell(p));

    if (button.equals("LeftButton")) {
      this.leftClicked(p, selectedCell);
    }
    else {
      if (button.equals("RightButton")) {
        this.rightClicked(p, selectedCell);
      }
    }
  }

  // update the game when the left mouse button has been clicked
  public void leftClicked(Posn p, Cell selected) {
    if (p.y > 100 && p.y < 740 && p.x > 20 && p.x < 1220) {
      selected.revealCell();
    }
    else {
      if (p.x >= 520 && p.x <= 680 && p.y >= 40 && p.y <= 80) {
        this.rows = new Utils().makeInitialRows();
        this.rand = new Random();
        this.timeCount = 0;
        this.addMines(this.generateMines());
        this.updateNeighbors();
      }
    }
  }

  // update the game when the right mouse button has been clicked
  public void rightClicked(Posn p, Cell selected) {
    if (p.y > 100 && p.y < 740 && p.x > 20 && p.x < 1220) {
      selected.flagClicked();
    }
  }

  // determine which cell in this game was clicked from the given coordinates
  public int determineCell(Posn p) {
    Row selectedRow = this.rows.get(this.determineRow(p));

    return selectedRow.determineCell(p.x);
  }

  // Determine the index of the Row clicked from the given coordinates of the
  // click
  public int determineRow(Posn p) {
    int rowIndex = 0;

    for (int i = 0; i < this.rows.size(); i++) {
      if (i * 40 + 100 <= p.y) {
        rowIndex = i;
      }
    }
    return this.rows.size() - rowIndex - 1;
  }

  // ------------------------------------------------------------------------------------

  // compute how many mines are left to be found in this Game
  public Integer minesLeft() {
    Integer totalMines = this.generateMines().size();
    Integer cellsFlagged = 0;
    for (Row r : this.rows) {
      cellsFlagged += r.countFlags();
    }
    return totalMines - cellsFlagged;
  }

  // ------------------------------------------------------------------------------------

  // end this world when the Game is over, either by win or loss
  public WorldEnd worldEnds() {
    return new WorldEnd(this.hasGameEnded(), this.drawEnding());
  }

  // has this game ended by clicking a mine or revealing all necessary cells?
  public boolean hasGameEnded() {
    return this.hasClickedMine() || this.onlyMinesLeft();
  }

  // have any cells containing mines in this game been clicked?
  public boolean hasClickedMine() {
    boolean trueYet = false;

    for (Row r : this.rows) {
      if (r.hasClickedMine()) {
        trueYet = true;
      }
    }
    return trueYet;
  }

  // are the only cells left to be revealed containing mines?
  public boolean onlyMinesLeft() {
    int unrevealedLeft = 0;

    for (Row r : this.rows) {
      unrevealedLeft += r.unrevealedLeft();
    }
    return unrevealedLeft == 0;
  }

  // draw the ending frame of this Game when the world has ended
  public WorldScene drawEnding() {
    WorldImage endingText = this.endingMesage();
    WorldScene background = new WorldScene((int) this.drawGame().getWidth(),
        (int) this.drawGame().getHeight());
    int width = (int) (this.drawGame().getWidth() / 2.0);
    int height = (int) (this.drawGame().getHeight() / 2.0);

    background.placeImageXY(endingText, width, height);
    return background;
  }

  // draw the appropriate ending message
  public WorldImage endingMesage() {
    if (this.hasClickedMine()) {
      return new TextImage("You Lost.", 40, Color.RED);
    }
    else {
      return new TextImage("You Won!", 40, Color.BLUE);
    }
  }

  // ------------------------------------------------------------------------------------

  // update the time counter on every tick to keep track of time that's passed
  public void onTick() {
    this.timeCount += 1;
  }

  // compute how many seconds have passed in this game
  public Integer currentTime() {
    return (int) ((this.timeCount * 1.0) / 28.0);
  }

}
