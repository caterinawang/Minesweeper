import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import javalib.worldimages.*;

// One cell of the Minesweeper game containing its neighboring cells
class Cell {
  boolean isRevealed;
  boolean hasMine;
  boolean isFlagged;
  ArrayList<Cell> neighbors;

  Integer cellDimension = 40;
  Integer textSize = 20;
  ArrayList<Color> colorList = new ArrayList<Color>(
      Arrays.asList(Color.BLUE, Color.GREEN, Color.RED, Color.PINK));
  WorldImage flag = new TriangleImage(new Posn(20, 10), new Posn(10, 30), new Posn(30, 30),
      OutlineMode.SOLID, Color.YELLOW);
  WorldImage bomb = new CircleImage(10, OutlineMode.SOLID, Color.RED);
  WorldImage frame = new RectangleImage(cellDimension, cellDimension, OutlineMode.OUTLINE,
      Color.BLACK);
  WorldImage unrevealed = new OverlayImage(frame,
      new RectangleImage(cellDimension, cellDimension, OutlineMode.SOLID, Color.BLUE));
  WorldImage revealed = new OverlayImage(frame,
      new RectangleImage(cellDimension, cellDimension, OutlineMode.SOLID, Color.LIGHT_GRAY));

  // a Cell constructor that takes all necessary values
  Cell(boolean isRevealed, boolean hasMine, boolean isFlagged, ArrayList<Cell> neighbors) {
    this.isRevealed = isRevealed;
    this.hasMine = hasMine;
    this.isFlagged = isFlagged;
    this.neighbors = neighbors;
  }

  // a Cell constructor that sets the neighbors as an empty list
  Cell(boolean isRevealed, boolean hasMine, boolean isFlagged) {
    this(isRevealed, hasMine, isFlagged, new ArrayList<Cell>());
  }

  // A Cell constructor that sets everything to the base level
  Cell() {
    this(false, false, false, new ArrayList<Cell>());
  }

  // ------------------------------------------------------------------------------------

  // how many direct neighbors of the Cell contain a Mine?
  public Integer neighboringMines() {
    Integer mines = 0;

    for (Cell c : this.neighbors) {
      if (c.hasMine) {
        mines += 1;
      }
    }
    return mines;
  }

  // ------------------------------------------------------------------------------------

  // draw this Cell as an Image
  public WorldImage drawCell() {
    if (this.isRevealed) {
      return this.drawRevealed();
    }
    else {
      if (this.isFlagged) {
        return new OverlayImage(flag, unrevealed);
      }
      else {
        return unrevealed;
      }
    }
  }

  // draw this Cell assuming it has been revealed
  public WorldImage drawRevealed() {
    if (this.hasMine) {
      return new OverlayImage(bomb, revealed);
    }
    else {
      return this.drawRevealedHelp();
    }
  }

  // draw this Cell, assuming it has been revealed and doesn't have a mine
  public WorldImage drawRevealedHelp() {
    if (this.neighboringMines() == 0) {
      return this.revealed;
    }
    else {
      return new OverlayImage(new TextImage(this.neighboringMines().toString(), textSize,
          colorList.get(this.neighboringMines() % 5 - 1)), revealed);
    }
  }

  // ------------------------------------------------------------------------------------

  // flag or un-flag this cell when it has been right-clicked
  public void flagClicked() {
    if (this.isFlagged) {
      this.isFlagged = false;
    }
    else {
      this.isFlagged = true;
    }
  }

  // reveal all neighboring cells and perform any flood filling
  public void revealCell() {
    this.isRevealed = true;
    this.floodFill();
  }

  // Fill this cell and its neighbors if it is Fillable
  public void floodFill() {
    if (this.neighboringMines() == 0) {
      this.floodFillHelp();
    }
  }

  // fill all neighboring cells that are fillable
  public void floodFillHelp() {
    for (Cell c : this.neighbors) {
      if (c.isFillable()) {
        c.revealCell();
      }
      else {
        if (c.neighboringMines() > 0) {
          c.isRevealed = true;
        }
      }
    }
  }

  // is this Cell fillable in a flood fill?
  public boolean isFillable() {
    return this.neighboringMines() == 0 && !this.hasMine && !this.isRevealed;
  }
}
