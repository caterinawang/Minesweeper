import java.util.ArrayList;
import javalib.worldimages.*;

// one row of Cells in a Minesweeper game
class Row {
  ArrayList<Cell> cells;

  Row(ArrayList<Cell> cells) {
    this.cells = cells;
  }

  // ------------------------------------------------------------------------------------

  // update the neighbors of each Cell in this Row, assuming this has one
  // neighboring row. The given Rows must be of the same size as this
  void updateNeighborsEdge(Row other) {
    for (int i = 0; i < this.cells.size(); i++) {
      ArrayList<Cell> currentList = this.cells.get(i).neighbors;

      if (i == 0) {
        currentList.add(this.cells.get(i + 1));
        currentList.add(other.cells.get(i));
        currentList.add(other.cells.get(i + 1));
      }
      else {
        this.updateEdgeHelp(other, i);
      }
    }
  }

  // update the neighbors of each Cell in this Row, ignoring the first cell
  // The given Rows must be of the same size as this
  void updateEdgeHelp(Row other, int i) {
    ArrayList<Cell> currentList = this.cells.get(i).neighbors;

    if (i + 1 == this.cells.size()) {
      currentList.add(this.cells.get(i - 1));
      currentList.add(other.cells.get(i));
      currentList.add(other.cells.get(i - 1));
    }
    else {
      currentList.add(this.cells.get(i + 1));
      currentList.add(this.cells.get(i - 1));
      currentList.add(other.cells.get(i - 1));
      currentList.add(other.cells.get(i));
      currentList.add(other.cells.get(i + 1));
    }
  }

  // update the neighbors of each Cell in this row, assuming it has two
  // neighboring rows. The given Rows must be of the same size as this
  void updateNeighborsMiddle(Row above, Row below) {
    for (int i = 0; i < this.cells.size(); i++) {
      Cell current = this.cells.get(i);

      if (i == 0) {
        current.neighbors.add(this.cells.get(i + 1));
        current.neighbors.add(above.cells.get(i));
        current.neighbors.add(above.cells.get(i + 1));
        current.neighbors.add(below.cells.get(i));
        current.neighbors.add(below.cells.get(i + 1));
      }
      else {
        this.updateMiddleHelp(above, below, i);
      }
    }
  }

  // Update the neighbors of each cell in this Row, ignoring the first cell
  // The given Rows must be of the same size as this
  void updateMiddleHelp(Row above, Row below, int i) {
    Cell current = this.cells.get(i);

    if (i + 1 == this.cells.size()) {
      current.neighbors.add(this.cells.get(i - 1));
      current.neighbors.add(above.cells.get(i));
      current.neighbors.add(above.cells.get(i - 1));
      current.neighbors.add(below.cells.get(i));
      current.neighbors.add(below.cells.get(i - 1));
    }
    else {
      current.neighbors.add(this.cells.get(i + 1));
      current.neighbors.add(this.cells.get(i - 1));
      current.neighbors.add(above.cells.get(i - 1));
      current.neighbors.add(above.cells.get(i));
      current.neighbors.add(above.cells.get(i + 1));
      current.neighbors.add(below.cells.get(i - 1));
      current.neighbors.add(below.cells.get(i));
      current.neighbors.add(below.cells.get(i + 1));
    }
  }

  // ------------------------------------------------------------------------------------

  // draw this Row of Cells
  WorldImage drawRow() {
    WorldImage drawnSoFar = new EmptyImage();

    for (Cell c : this.cells) {
      drawnSoFar = new BesideImage(c.drawCell(), drawnSoFar);
    }
    return drawnSoFar;
  }

  // ------------------------------------------------------------------------------------

  // determine which Cell in this Row was clicked based on the given x-coordinate
  public int determineCell(int xPos) {
    int cellIndex = 0;

    for (int i = 0; i < this.cells.size(); i++) {
      if (i * 40 + 20 <= xPos) {
        cellIndex = i;
      }
    }
    return this.cells.size() - cellIndex - 1;
  }

  // ------------------------------------------------------------------------------------

  // have any cells in this row that contain a mine been revealed?
  public boolean hasClickedMine() {
    boolean trueYet = false;

    for (Cell c : this.cells) {
      if (c.isRevealed && c.hasMine) {
        trueYet = true;
      }
    }
    return trueYet;
  }

  // compute how many cells in this Row that don't contain a mine are yet to be
  // revealed
  public int unrevealedLeft() {
    int unrevealedLeft = 0;

    for (Cell c : this.cells) {
      if (!c.isRevealed && !c.hasMine) {
        unrevealedLeft += 1;
      }
    }
    return unrevealedLeft;
  }

  // ------------------------------------------------------------------------------------

  // compute how many Cells in this Row are flagged
  public Integer countFlags() {
    Integer flagCount = 0;

    for (Cell c : this.cells) {
      if (c.isFlagged && !c.isRevealed) {
        flagCount += 1;
      }
    }
    return flagCount;
  }
}
