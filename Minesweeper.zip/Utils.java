import java.util.ArrayList;

// a class for utility/helper functions
class Utils {

  // make the initial list of Rows for the game
  ArrayList<Row> makeInitialRows() {
    int rowCount = 0;
    ArrayList<Row> soFar = new ArrayList<Row>();

    while (rowCount < 16) {
      soFar.add(new Utils().makeInititalRow());
      rowCount += 1;
    }
    return soFar;
  }

  // make a Row of the initial state of the Game with 30 cells
  Row makeInititalRow() {
    int cellCount = 0;
    ArrayList<Cell> soFar = new ArrayList<Cell>();

    while (cellCount < 30) {
      soFar.add(new Cell());
      cellCount += 1;
    }
    return new Row(soFar);
  }
}
